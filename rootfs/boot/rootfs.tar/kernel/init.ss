rmount /mnt/sata0p2 rw
